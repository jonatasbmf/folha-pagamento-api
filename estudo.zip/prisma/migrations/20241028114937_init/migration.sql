-- CreateTable
CREATE TABLE "Usuario" (
    "id" SERIAL NOT NULL,
    "email" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "senha" TEXT NOT NULL,

    CONSTRAINT "Usuario_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "AliquotasINSS" (
    "id" SERIAL NOT NULL,
    "ano" INTEGER NOT NULL,
    "faixa_min" DOUBLE PRECISION NOT NULL,
    "faixa_max" DOUBLE PRECISION,
    "aliquota" DOUBLE PRECISION NOT NULL,

    CONSTRAINT "AliquotasINSS_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "AliquotasIRRF" (
    "id" SERIAL NOT NULL,
    "ano" INTEGER NOT NULL,
    "faixa_min" DOUBLE PRECISION NOT NULL,
    "faixa_max" DOUBLE PRECISION,
    "aliquota" DOUBLE PRECISION NOT NULL,
    "deducao" DOUBLE PRECISION NOT NULL,

    CONSTRAINT "AliquotasIRRF_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Empresa" (
    "id" SERIAL NOT NULL,
    "nome" TEXT NOT NULL,
    "razao_social" TEXT NOT NULL,
    "email" TEXT NOT NULL,

    CONSTRAINT "Empresa_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Funcionario" (
    "id" SERIAL NOT NULL,
    "nome" TEXT NOT NULL,
    "salario" DOUBLE PRECISION NOT NULL,
    "email" TEXT NOT NULL,

    CONSTRAINT "Funcionario_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "Usuario_email_key" ON "Usuario"("email");
