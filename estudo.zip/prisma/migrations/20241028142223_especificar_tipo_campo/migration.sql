/*
  Warnings:

  - You are about to alter the column `faixa_min` on the `AliquotasINSS` table. The data in that column could be lost. The data in that column will be cast from `DoublePrecision` to `Decimal(12,2)`.
  - You are about to alter the column `faixa_max` on the `AliquotasINSS` table. The data in that column could be lost. The data in that column will be cast from `DoublePrecision` to `Decimal(12,2)`.
  - You are about to alter the column `aliquota` on the `AliquotasINSS` table. The data in that column could be lost. The data in that column will be cast from `DoublePrecision` to `Decimal(12,2)`.
  - You are about to alter the column `faixa_min` on the `AliquotasIRRF` table. The data in that column could be lost. The data in that column will be cast from `DoublePrecision` to `Decimal(12,2)`.
  - You are about to alter the column `faixa_max` on the `AliquotasIRRF` table. The data in that column could be lost. The data in that column will be cast from `DoublePrecision` to `Decimal(12,2)`.
  - You are about to alter the column `aliquota` on the `AliquotasIRRF` table. The data in that column could be lost. The data in that column will be cast from `DoublePrecision` to `Decimal(12,2)`.
  - You are about to alter the column `deducao` on the `AliquotasIRRF` table. The data in that column could be lost. The data in that column will be cast from `DoublePrecision` to `Decimal(12,2)`.
  - You are about to alter the column `nome` on the `Empresa` table. The data in that column could be lost. The data in that column will be cast from `Text` to `VarChar(150)`.
  - You are about to alter the column `razao_social` on the `Empresa` table. The data in that column could be lost. The data in that column will be cast from `Text` to `VarChar(150)`.
  - You are about to alter the column `email` on the `Empresa` table. The data in that column could be lost. The data in that column will be cast from `Text` to `VarChar(150)`.
  - You are about to alter the column `nome` on the `Funcionario` table. The data in that column could be lost. The data in that column will be cast from `Text` to `VarChar(150)`.
  - You are about to alter the column `salario` on the `Funcionario` table. The data in that column could be lost. The data in that column will be cast from `DoublePrecision` to `Decimal(12,2)`.
  - You are about to alter the column `email` on the `Usuario` table. The data in that column could be lost. The data in that column will be cast from `Text` to `VarChar(150)`.
  - You are about to alter the column `name` on the `Usuario` table. The data in that column could be lost. The data in that column will be cast from `Text` to `VarChar(150)`.
  - You are about to alter the column `senha` on the `Usuario` table. The data in that column could be lost. The data in that column will be cast from `Text` to `VarChar(255)`.

*/
-- AlterTable
ALTER TABLE "AliquotasINSS" ALTER COLUMN "faixa_min" SET DATA TYPE DECIMAL(12,2),
ALTER COLUMN "faixa_max" SET DATA TYPE DECIMAL(12,2),
ALTER COLUMN "aliquota" SET DATA TYPE DECIMAL(12,2);

-- AlterTable
ALTER TABLE "AliquotasIRRF" ALTER COLUMN "faixa_min" SET DATA TYPE DECIMAL(12,2),
ALTER COLUMN "faixa_max" SET DATA TYPE DECIMAL(12,2),
ALTER COLUMN "aliquota" SET DATA TYPE DECIMAL(12,2),
ALTER COLUMN "deducao" SET DATA TYPE DECIMAL(12,2);

-- AlterTable
ALTER TABLE "Empresa" ALTER COLUMN "nome" SET DATA TYPE VARCHAR(150),
ALTER COLUMN "razao_social" SET DATA TYPE VARCHAR(150),
ALTER COLUMN "email" SET DATA TYPE VARCHAR(150);

-- AlterTable
ALTER TABLE "Funcionario" ALTER COLUMN "nome" SET DATA TYPE VARCHAR(150),
ALTER COLUMN "salario" SET DATA TYPE DECIMAL(12,2);

-- AlterTable
ALTER TABLE "Usuario" ALTER COLUMN "email" SET DATA TYPE VARCHAR(150),
ALTER COLUMN "name" SET DATA TYPE VARCHAR(150),
ALTER COLUMN "senha" SET DATA TYPE VARCHAR(255);
