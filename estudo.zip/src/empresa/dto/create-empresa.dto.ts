export class CreateEmpresaDto {
    nome: string;
    razao_social: string;
    email: string;
}
