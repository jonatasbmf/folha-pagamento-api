export class Empresa {
    id: number;
    nome: string;
    razao_social: string;
    email: string;
}
