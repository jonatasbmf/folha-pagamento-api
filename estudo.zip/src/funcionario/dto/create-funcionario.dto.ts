export class CreateFuncionarioDto {
    nome: string;
    salario: number;
    empresaId: number;
}