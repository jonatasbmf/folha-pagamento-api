export class Funcionario {
    id: number;
    nome: string;
    salario: number;
    empresaId: number;
}