export class CreateUsuarioDto {
    email: string;
    name: string;
    senha: string;
}