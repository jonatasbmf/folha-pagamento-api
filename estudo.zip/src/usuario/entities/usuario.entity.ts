export class Usuario {
    id: number;
    email: string;
    name: string;
    senha: string;
    salt: string;
}